INSTALLATION OF BCD3000 WINDOWS XP/VISTA/7 32/64-BIT DRIVER 1.3.4
=================================================================

This is the updated installation routine for the BCD3000 driver.For installation 

please double-click the setup.exe file and follow the on-screen 

instructions. 

